import { NextResponse } from "next/server";
import { adminPasswordError } from "@/lib/auth/admin-password";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { checkOtp, otpCheckResponse } from "@/lib/auth/otp";
import { passwordPolicyError } from "@/lib/auth/password-policy";
import { endAllSessions } from "@/lib/auth/sessions";
import { clearAttempts } from "@/lib/auth/login-attempts";
import { invalidateBanCache } from "@/lib/auth/verify-token";

/**
 * @swagger
 * /api/auth/reset-password:
 *   post:
 *     summary: Choose a new password with the one-time code that was emailed
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [email, code, newPassword]
 *             properties:
 *               email:
 *                 type: string
 *               code:
 *                 type: string
 *               newPassword:
 *                 type: string
 */
export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const code = typeof body.code === "string" ? body.code : "";
    const newPassword = typeof body.newPassword === "string" ? body.newPassword : "";

    const weak = passwordPolicyError(newPassword);
    if (weak) return NextResponse.json(weak, { status: 400 });

    const user = email ? await prisma.user.findUnique({ where: { email }, select: { id: true, isBanned: true, role: true } }) : null;
    if (!user || user.isBanned || !code) {
      return NextResponse.json({ error: "Invalid or expired verification code." }, { status: 400 });
    }

    if (user.role === "SUPER_ADMIN" && adminPasswordError(newPassword)) {
      return NextResponse.json({ error: adminPasswordError(newPassword) }, { status: 400 });
    }

    // Uses the code up: it works once, within ten minutes, and cancels itself after five wrong guesses
    const check = await checkOtp(user.id, "PASSWORD_RESET", code);
    if (!check.ok) return otpCheckResponse(check);

    const passwordHash = await bcrypt.hash(newPassword, 10);
    await prisma.user.update({ where: { id: user.id }, data: { passwordHash, ...endAllSessions() } });
    // Any other reset or sign-in code still waiting is cancelled, the sign-in lockout is lifted and old sessions end
    await prisma.otpCode.updateMany({ where: { userId: user.id, isUsed: false }, data: { isUsed: true } });
    await clearAttempts(email);
    invalidateBanCache(user.id);

    return NextResponse.json({ message: "Password updated. Please sign in with your new password." });
  } catch (error) {
    console.error("[Reset password]:", error);
    return NextResponse.json({ error: "Internal server error." }, { status: 500 });
  }
}
