import { suspendedResponse } from "@/lib/auth/verify-token";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { signSessionToken } from "@/lib/auth/sessions";
import { checkOtp, otpCheckResponse } from "@/lib/auth/otp";

/**
 * @swagger
 * /api/auth/verify-login:
 *   post:
 *     summary: تأكيد الدخول (يرجع Token)
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [userId, code]
 *             properties:
 *               userId:
 *                 type: string
 *               code:
 *                 type: string
 *     responses:
 *       200:
 *         description: تم تسجيل الدخول، يرجع token
 */

export async function POST(request: Request) {
  try {
    const { userId, code } = await request.json();

    if (!userId || !code) {
      return NextResponse.json({ error: "User ID and verification code are required." }, { status: 400 });
    }

    // The newest unused, unexpired code only; wrong guesses are counted and cancel the code after five
    const check = await checkOtp(userId, "LOGIN", String(code));
    if (!check.ok) {
      return otpCheckResponse(check);
    }

    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: {
        hrAdminOf: true,
        company: true,
      },
    });

    if (!user) {
      return NextResponse.json({ error: "User not found." }, { status: 404 });
    }

    if (!user.emailVerified) {
     return NextResponse.json({ error: "Please verify your email address first." }, { status: 403 });
    }
    if (user.isBanned) {
      return suspendedResponse();
    }

    let partnerInfo = null;
    if (user.role === "PARTNER_ADMIN") {
      partnerInfo = await prisma.partner.findFirst({
        where: { contactEmail: { equals: user.email, mode: "insensitive" } }, orderBy: { createdAt: 'asc' },
      });
      if (partnerInfo && partnerInfo.status === "PENDING_APPROVAL") {
        return NextResponse.json({
          error: "Your partner account is currently under review by platform administrators. You will receive an email once approved.",
          code: "PARTNER_PENDING_APPROVAL",
        }, { status: 403 });
      }
      if (partnerInfo && partnerInfo.status === "REJECTED") {
        return NextResponse.json({
          error: "Your partner registration request has been declined. Please contact support.",
          code: "PARTNER_REJECTED",
        }, { status: 403 });
      }
    }

    // Unique per sign-in, so signing out one device never signs out another
    const token = signSessionToken(user);

    const associatedCompany = user.hrAdminOf || user.company;

    return NextResponse.json({
      message: "Logged in successfully.",
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        companyId: associatedCompany?.id || user.companyId || null,
        companyName: associatedCompany?.companyName || null,
        orgName: associatedCompany?.companyName || null,
        businessName: partnerInfo?.brandName || null,
        crNumber: partnerInfo?.taxNumber || null,
        partnerStatus: partnerInfo?.status || null,
      },
    });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Internal server error." }, { status: 500 });
  }
}

