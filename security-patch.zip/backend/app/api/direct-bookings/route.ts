import { settleCheckout } from "@/lib/security/checkout";
import { idempotent } from "@/lib/security/idempotency";
import { money, positiveInteger, inputResponse, InputError } from "@/lib/security/input";
import { NextRequest, NextResponse } from 'next/server';
import { resolveAttendeeIds, notifyAttendees } from '@/lib/company/team';
import { prisma } from '@/lib/prisma';
import { getTokenFromRequest, unauthorizedResponse, suspendedResponse } from '@/lib/auth/verify-token';
import { getOwnedWorkspaceIds } from '@/lib/ownership';
import { directBookingEffectiveStatus } from '@/lib/booking/lifecycle';
import { directBookingEnd, effectiveCapacity, getOccupiedSeats, getOccupiedSeatsForSection } from '@/lib/booking/capacity';
import { hiddenWorkspaceError } from '@/lib/workspaces/visibility';
import { getKsaNow, parseDateAndTimeToKsaDate } from '@/lib/time-utils';
import type { Prisma, DurationType, DirectBookingStatus } from "@prisma/client";
import { errorMessage } from '@/lib/errors';

export async function GET(request: Request) {
  try {
    const user = await getTokenFromRequest(request);
    if (!user) {
      return unauthorizedResponse(request);
    }

    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const workspaceId = searchParams.get('workspaceId');
    const sectionId = searchParams.get('sectionId');
    const status = searchParams.get('status');

    const whereClause: Prisma.DirectBookingWhereInput = {};
    if (user.role === 'SUPER_ADMIN') {
      if (userId) whereClause.userId = userId;
    } else if (user.role === 'PARTNER_ADMIN') {
      // A partner sees bookings made at their own workspaces, plus any they made themselves as a customer
      const owned = await getOwnedWorkspaceIds(user.userId);
      const and: Prisma.DirectBookingWhereInput[] = [{ OR: [{ workspaceId: { in: owned } }, { userId: user.userId }, { attendeeIds: { has: user.userId } }] }];
      if (userId) and.push({ userId });
      whereClause.AND = and;
    } else {
      // Own bookings plus the company bookings made for this person
      whereClause.OR = [{ userId: user.userId }, { attendeeIds: { has: user.userId } }];
    }

    if (workspaceId) whereClause.workspaceId = workspaceId;
    if (sectionId) whereClause.sectionId = sectionId;
    if (status) whereClause.status = status as DirectBookingStatus;

    const bookings = await prisma.directBooking.findMany({
      where: whereClause,
      include: {
        user: { select: { id: true, name: true, email: true, role: true, companyId: true } },
        workspace: true,
        section: true,
      },
      orderBy: [{ bookingDate: 'desc' }, { createdAt: 'desc' }],
    });

    return NextResponse.json(bookings.map((b) => ({ ...b, effectiveStatus: directBookingEffectiveStatus(b) })));
  } catch (error) {
    console.error(' Error fetching direct bookings:', error);
    return NextResponse.json(
      { error: 'Failed to fetch direct bookings.' },
      { status: 500 }
    );
  }
}

/**
 * @swagger
 * /api/direct-bookings:
 *   post:
 *     summary: إنشاء حجز مباشر
 *     security:
 *       - BearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [userId, workspaceId, sectionId, durationType, bookingDate]
 *             properties:
 *               userId:
 *                 type: string
 *               workspaceId:
 *                 type: string
 *               sectionId:
 *                 type: string
 *               durationType:
 *                 type: string
 *                 enum: [DAILY, MONTHLY, YEARLY]
 *               bookingDate:
 *                 type: string
 *     responses:
 *       201:
 *         description: تم إنشاء الحجز (أو تسجيله بالطابور لو المساحة ممتلئة). لو المستخدم مرتبط بشركة، يُخصم تلقائياً من رصيد محفظة الشركة.
 *       400:
 *         description: رصيد الشركة غير كافٍ لهذا الحجز
 */
export const POST = idempotent("direct-bookings", async (request, db) => {
  try {
    const user = await getTokenFromRequest(request);
    if (!user) return unauthorizedResponse(request);

    const body = await request.json();
    const { userId, workspaceId, sectionId, durationType, durationDays, durationMonths, bookingDate } = body;

    // تطبيع المدينة
    // Bookings always belong to the authenticated caller; only super admins may book on behalf of others
    const effectiveUserId: string = user.role === 'SUPER_ADMIN' && userId ? userId : user.userId;

    const bookingOwner = await db.user.findUnique({ where: { id: effectiveUserId }, select: { id: true, isBanned: true } });
    if (!bookingOwner) {
      return NextResponse.json({ error: 'User not found.' }, { status: 404 });
    }
    if (bookingOwner.isBanned) {
      return suspendedResponse();
    }

    const validDurations = ['DAILY', 'MONTHLY', 'YEARLY'];
    const normalizedDuration = typeof durationType === 'string' ? durationType.toUpperCase() : 'DAILY';
    if (!validDurations.includes(normalizedDuration)) throw new InputError('Invalid duration type.');
    const finalDuration = normalizedDuration;

    //  BE-07: منع الحجز المتزامن (Universal Pass)
    const activeBooking = await db.directBooking.findFirst({
      where: {
        userId: effectiveUserId,
        status: 'CONFIRMED',
        bookingDate: { gte: getKsaNow() }
      }
    });

    if (activeBooking) {
      return NextResponse.json(
        { 
          error: 'You already have an active booking. Cancel it before booking another space.',
          activeBookingId: activeBooking.id
        },
        { status: 400 }
      );
    }

    const ws = await db.workspace.findUnique({ where: { id: workspaceId || "" }, include: { sections: true } });
    const sec = ws?.sections.find(s => s.id === sectionId);
    if (!ws || !sec) throw new InputError("Select an existing workspace and section.");
    const targetWorkspaceId = ws.id;
    const targetSectionId = sec.id;
    const units = positiveInteger(finalDuration === 'DAILY' ? durationDays : finalDuration === 'MONTHLY' ? durationMonths : 1, 1, finalDuration === 'DAILY' ? 365 : 12);
    const seats = positiveInteger(body.seats, 1, 1000);
    const rate = finalDuration === 'DAILY' ? sec.dailyRate : finalDuration === 'MONTHLY' ? sec.monthlyRate : sec.yearlyRate;
    const payableAmount = money(money(rate) * units * seats);

    const finalDurationDetails = `${units} ${finalDuration === 'DAILY' ? 'Days' : finalDuration === 'MONTHLY' ? 'Months' : 'Year'}`;

    // Hidden workspaces cannot be booked by the public
    const hiddenError = await hiddenWorkspaceError(targetWorkspaceId, user);
    if (hiddenError) {
      return NextResponse.json({ error: hiddenError }, { status: 403 });
    }

    // Capacity check + insert run under a per-workspace advisory lock, so simultaneous requests for the
    // last seats cannot both pass the check (no overbooking). Shares its lock key with hourly bookings.
    // Team members this company booking is for (only an HR admin's own team members are kept)
    const attendeeIds = await resolveAttendeeIds(effectiveUserId, body.attendeeIds);
    const lockedWorkspaceId: string = targetWorkspaceId;
    const created = await (async (tx: typeof db) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${'hourly-slot:' + lockedWorkspaceId}))`;

    // Capacity check: reject requests that would exceed the venue's total seats for the booked period
    const requestedSeats = seats;
    const bookingStart = parseDateAndTimeToKsaDate(bookingDate, null, 9);

    if (ws.sections.length > 1 && sec.capacity > 0) {
      // A hub with several rooms: each room seats only its own capacity
      const roomEnd = directBookingEnd({ bookingDate: bookingStart, durationType: finalDuration, durationDetails: finalDurationDetails });
      const roomOccupied = await getOccupiedSeatsForSection(sec.id, bookingStart, roomEnd);
      if (roomOccupied + requestedSeats > sec.capacity) {
        return NextResponse.json(
          { error: `${sec.name} has only ${Math.max(0, sec.capacity - roomOccupied)} seat(s) left for the selected period.` },
          { status: 409 }
        );
      }
    } else {
      const seatLimit = effectiveCapacity(ws);
      const bookingEnd = directBookingEnd({ bookingDate: bookingStart, durationType: finalDuration, durationDetails: finalDurationDetails });
      const occupied = (await getOccupiedSeats([targetWorkspaceId], bookingStart, bookingEnd)).get(targetWorkspaceId) || 0;
      if (occupied + requestedSeats > seatLimit) {
        return NextResponse.json(
          { error: `Not enough availability. Only ${Math.max(0, seatLimit - occupied)} seat(s) left for the selected period.` },
          { status: 409 }
        );
      }
    }

    const booking = await tx.directBooking.create({
      data: {
        userId: effectiveUserId,
        payableAmount,
        attendeeIds,
        seats: requestedSeats,
        workspaceId: targetWorkspaceId,
        sectionId: targetSectionId,
        durationType: finalDuration as DurationType,
        durationDetails: finalDurationDetails,
        bookingDate: parseDateAndTimeToKsaDate(bookingDate, null, 9),
        status: 'CONFIRMED',
        createdAt: getKsaNow(),
      },
      include: {
        user: { select: { id: true, name: true, email: true, role: true, companyId: true } },
        workspace: true,
        section: true,
      },
    });
    await settleCheckout(tx, effectiveUserId, booking.id, "DIRECT_BOOKING", payableAmount, ws.id);
    return booking;
    })(db);

    // A NextResponse here means the capacity check inside the transaction rejected the request
    if (created instanceof NextResponse) return created;
    const booking = created;

    await db.notification.create({
      data: {
        userId: effectiveUserId,
        type: 'BOOKING_CONFIRMED',
        title: 'Booking Confirmed',
        message: `Your booking at ${booking.workspace.name} has been confirmed successfully.`,
        channel: 'IN_APP',
        sentAt: getKsaNow()
      }
    }).catch(() => {});

    await notifyAttendees(
      attendeeIds,
      booking.workspace.name,
      booking.section?.name,
      `${booking.bookingDate.toISOString().slice(0, 10)}, ${booking.durationDetails || booking.durationType.toLowerCase()}`
    );

    return NextResponse.json(booking, { status: 201 });
  } catch (error) {
    const invalid = inputResponse(error);
    if (invalid) return invalid;
    console.error('❌ Error creating direct booking:', error);
    return NextResponse.json(
      { error: errorMessage(error, 'Failed to create direct booking.') },
      { status: 500 }
    );
  }
});
